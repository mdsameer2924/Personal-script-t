-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")

-- Remap delete and change operations to use the black hole register
vim.keymap.set({ "n", "v" }, "d", '"_d', { desc = "Delete without copying" })
vim.keymap.set({ "n", "v" }, "D", '"_D', { desc = "Delete line without copying" })
vim.keymap.set({ "n", "v" }, "c", '"_c', { desc = "Change without copying" })
vim.keymap.set({ "n", "v" }, "C", '"_C', { desc = "Change line without copying" })
vim.keymap.set({ "n", "v" }, "x", '"_x', { desc = "Delete char without copying" })
