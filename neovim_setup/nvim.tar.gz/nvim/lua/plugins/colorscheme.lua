return {
  -- Keeps vscode installed in the background without loading it at startup
  {
    "Mofiqul/vscode.nvim",
    lazy = true,
  },

  -- Installs and loads Kanagawa Dragon as your active theme
  {
    "rebelot/kanagawa.nvim",
    lazy = false,
    priority = 1000,
    opts = {
      theme = "dragon",
      background = {
        dark = "dragon",
        light = "lotus",
      },
    },
  },

  {
    "projekt0n/github-nvim-theme",
    lazy = false,
    priority = 1000,
  },
  -- Add the PyCharm/Darcula colorscheme
  {
    "doums/darcula",
    lazy = false,
    priority = 1000,
  },

  -- Tells LazyVim to apply Kanagawa Dragon on launch
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "kanagawa-dragon",
    },
  },
}
