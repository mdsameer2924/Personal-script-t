-- lua/plugins/ui.lua
return {
  { "nvim-neo-tree/neo-tree.nvim", enabled = false },
  { "folke/trouble.nvim", enabled = false },
  { "folke/which-key.nvim", enabled = true },
}
