return {
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      { "mason-org/mason.nvim", opts = {} },
      {
        "mason-org/mason-lspconfig.nvim",
        opts = {
          ensure_installed = { "gopls" }, -- Automatically installs gopls
        },
      },
    },
    config = function()
      local lspconfig = require("lspconfig")
      local util = require("lspconfig/util")

      lspconfig.gopls.setup({
        cmd = { "gopls" },
        filetypes = { "go", "gomod", "gowork", "gotmpl" },
        root_dir = util.root_pattern("go.work", "go.mod", ".git"),
        settings = {
          gopls = {
            completeUnimported = true, -- Auto-imports packages as you type
            usePlaceholders = true, -- Adds parameter placeholders to functions
            analyses = {
              unusedparams = true, -- Warns about unused parameters
            },
          },
        },
      })
    end,
  },
}
