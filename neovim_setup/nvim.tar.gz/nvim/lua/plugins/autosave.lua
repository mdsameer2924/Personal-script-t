return {
  "okuuva/auto-save.nvim",
  version = "^1.0.0",
  cmd = "ASToggle",
  event = { "InsertLeave", "TextChanged" },
  opts = {
    enabled = false, -- disable auto save entirely to enable use true,
    debounce_delay = 1000,
  },
}
