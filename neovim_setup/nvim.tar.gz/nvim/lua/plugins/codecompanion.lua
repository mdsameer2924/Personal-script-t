return {
  "olimorris/codecompanion.nvim",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-treesitter/nvim-treesitter",
    "xinghe98/codecompanion-model-selector.nvim",
  },
  config = function()
    require("codecompanion").setup({
      strategies = {
        chat = {
          adapter = "ollama", -- Default to your local free model
        },
      },
      adapters = {
        ollama = function()
          return require("codecompanion.adapters").use("ollama", {
            schema = {
              model = {
                default = "qwen2.5-coder",
              },
            },
          })
        end,
      },
    })
  end,
  keys = {
    { "<leader>ac", "<cmd>CodeCompanionChat Toggle<CR>", desc = "Toggle AI Chat" },
    {
      "<leader>am",
      function()
        require("cc_model_selector").select_adapter_and_model()
      end,
      desc = "Switch AI Model Interactively",
    },
  },
}
