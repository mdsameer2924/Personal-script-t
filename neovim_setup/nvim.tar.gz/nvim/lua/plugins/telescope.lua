-- lua/plugins/telescope.lua
return {
  "nvim-telescope/telescope.nvim",
  opts = {
    defaults = {
      -- Prevent telescope from scanning heavy hidden directories
      file_ignore_patterns = {
        "^.git/",
        "^node_modules/",
        "^.venv/",
      },
    },
    pickers = {
      find_files = {
        -- Shows hidden dotfiles (.bashrc, .env, .config, etc.)
        hidden = true,
        -- Set to true if you also want files listed in .gitignore
        no_ignore = false,
      },
    },
  },
}
