return {
  {
    "MeanderingProgrammer/render-markdown.nvim",
    opts = {
      code = {
        sign = false,
        width = "block",
        right_pad = 2,
      },
      checkbox = {
        enabled = true,
      },
    },
  },
}
