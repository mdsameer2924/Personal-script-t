-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options here
-- lua/config/options.lua

-- Netrw: Show all files including hidden/dotfiles by default
-- 0 = show all files, 1 = hide dotfiles, 2 = hide files matching g:netrw_list_hide
vim.g.netrw_hide = 0

-- Optional Netrw UI improvements:
vim.g.netrw_banner = 0 -- Hide the top help banner
vim.g.netrw_liststyle = 3 -- Tree view style (similar to a sidebar tree)
vim.g.netrw_winsize = 25 -- Width of split window when opened
vim.opt.timeoutlen = 30
