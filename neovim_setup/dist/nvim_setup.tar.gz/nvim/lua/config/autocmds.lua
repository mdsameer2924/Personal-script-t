-- Autocmds are automatically loaded on the VeryLazy event
-- Default autocmds that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/autocmds.lua
--
-- Add any additional autocmds here
-- with `vim.api.nvim_create_autocmd`
--
-- Or remove existing autocmds by their group name (which is prefixed with `lazyvim_` for the defaults)
-- e.g. vim.api.nvim_del_augroup_by_name("lazyvim_wrap_spell")

-- Toggle conceal level based on mode for Markdown files
vim.api.nvim_create_autocmd({ "FileType" }, {
  pattern = "markdown",
  callback = function()
    vim.opt_local.conceallevel = 2

    -- Show raw markdown symbols in Insert mode
    vim.api.nvim_create_autocmd("InsertEnter", {
      buffer = 0,
      callback = function()
        vim.opt_local.conceallevel = 0
      end,
    })

    -- Hide markdown symbols again when returning to Normal mode
    vim.api.nvim_create_autocmd("InsertLeave", {
      buffer = 0,
      callback = function()
        vim.opt_local.conceallevel = 2
      end,
    })
  end,
})
